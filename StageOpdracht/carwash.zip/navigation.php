<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
</head>
<body>
	<nav>
		<div class="nav_inner">
			<h1 class="CarWash">Car <span class="navspan">Wash<span></h1>
			<ul class="navmenu">
				<li class="menu_item"><a href="home.php">Home</a></li>
				<li class="menu_item"><a href="reviews.php">Reviews</a></li>
				<li class="menu_item"><a href="contact.php">Contact</a></li>
			</ul>
		</div>
	</nav>
</body>